Product 1 sample asset bundle
