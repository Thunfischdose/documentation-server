# Automation Playbook

Run this script to bootstrap staging.
